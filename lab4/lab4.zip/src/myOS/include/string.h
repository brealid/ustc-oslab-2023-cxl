#ifndef __STRING_H__
#define __STRING_H__

int strcmp(const char *str1, char *str2);
int strncpy(const char *src, const char *dest, unsigned int n);

#endif